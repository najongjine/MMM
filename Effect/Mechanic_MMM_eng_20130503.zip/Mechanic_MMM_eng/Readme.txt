//////////////////////////////////////////////////////////////////////////////
// Mechanic shader for MikuMikuMoving
// 2013/05/03
//////////////////////////////////////////////////////////////////////////////

Mechanic shader for MikuMikuMoving.
Original mechanic shader is developed by Beamman-P
http://www43.atwiki.jp/beamman/



Usage
==============================================================================
1. Select texture folder and open
2. Load Mechanic_v2_0.fxm on MMM
3. Assign the shader


Thanks
==============================================================================
Thank you Beamman-P!


Disclaimer
==============================================================================
In no event shall the author of this Software be liable for any damages arising out of the use of or inability to use the product.

